import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogOut, Bell, User, MessageCircle } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const Header: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (!user) return null;

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/dashboard" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">MC</span>
            </div>
            <span className="text-xl font-bold text-gray-900">MentorConnect</span>
          </Link>

          <nav className="hidden md:flex items-center space-x-6">
            <Link to="/dashboard" className="nav-link">
              Dashboard
            </Link>
            {user.type === 'mentee' && (
              <Link to="/mentors" className="nav-link">
                Encontrar Mentores
              </Link>
            )}
            {user.type === 'mentor' && (
              <Link to="/sessions" className="nav-link">
                Minhas Sessões
              </Link>
            )}
            <Link to="/messages" className="nav-link">
              Mensagens
            </Link>
            {user.type === 'admin' && (
              <Link to="/admin" className="nav-link">
                Administração
              </Link>
            )}
          </nav>

          <div className="flex items-center space-x-4">
            <button className="p-2 text-gray-400 hover:text-gray-600 relative">
              <Bell className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-warning-500 rounded-full text-xs text-white flex items-center justify-center">
                3
              </span>
            </button>
            
            <button className="p-2 text-gray-400 hover:text-gray-600 relative">
              <MessageCircle className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-success-500 rounded-full text-xs text-white flex items-center justify-center">
                2
              </span>
            </button>

            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-gray-600" />
              </div>
              <div className="hidden md:block">
                <p className="text-sm font-medium text-gray-900">{user.name}</p>
                <p className="text-xs text-gray-500 capitalize">{user.type}</p>
              </div>
            </div>

            <button
              onClick={handleLogout}
              className="p-2 text-gray-400 hover:text-gray-600"
              title="Sair"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};