import React, { useState } from 'react';
import { Calendar, Clock, Star, MapPin, Video, MessageSquare } from 'lucide-react';

export const SessionBooking: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [sessionType, setSessionType] = useState('video');
  const [topic, setTopic] = useState('');
  const [description, setDescription] = useState('');

  const mentor = {
    id: '1',
    name: 'Ana Silva',
    title: 'Senior Product Manager',
    company: 'Nubank',
    rating: 4.9,
    reviewCount: 127,
    hourlyRate: 150,
    avatar: 'AS',
    expertise: ['Product Management', 'Growth', 'Strategy'],
    bio: 'Especialista em product management com 8+ anos de experiência em fintechs.',
  };

  const availableSlots = [
    { date: '2024-01-15', day: 'Segunda', slots: ['09:00', '10:30', '14:00', '16:00'] },
    { date: '2024-01-16', day: 'Terça', slots: ['09:00', '11:00', '15:30'] },
    { date: '2024-01-17', day: 'Quarta', slots: ['10:00', '14:00', '16:30'] },
    { date: '2024-01-18', day: 'Quinta', slots: ['09:30', '13:00', '15:00'] },
    { date: '2024-01-19', day: 'Sexta', slots: ['10:00', '14:30'] },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle session booking
    console.log('Booking session:', {
      date: selectedDate,
      time: selectedTime,
      type: sessionType,
      topic,
      description,
    });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Agendar Sessão</h1>
        <p className="text-gray-600 mt-2">Escolha o melhor horário para sua mentoria</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Mentor Info */}
        <div className="lg:col-span-1">
          <div className="card p-6 sticky top-8">
            <div className="flex items-center space-x-4 mb-4">
              <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center">
                <span className="text-primary-600 font-semibold text-lg">{mentor.avatar}</span>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{mentor.name}</h3>
                <p className="text-primary-600 font-medium">{mentor.title}</p>
                <p className="text-gray-600 text-sm">{mentor.company}</p>
              </div>
            </div>

            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <Star className="w-4 h-4 text-warning-500 fill-current mr-1" />
                <span className="text-sm text-gray-600">{mentor.rating} ({mentor.reviewCount} avaliações)</span>
              </div>
              <span className="text-lg font-bold text-gray-900">R$ {mentor.hourlyRate}/h</span>
            </div>

            <p className="text-gray-700 text-sm mb-4">{mentor.bio}</p>

            <div className="flex flex-wrap gap-1">
              {mentor.expertise.map((skill) => (
                <span key={skill} className="text-xs bg-primary-100 text-primary-700 px-2 py-1 rounded">
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Booking Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="card p-6 space-y-6">
            {/* Session Type */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Tipo de Sessão
              </label>
              <div className="grid grid-cols-2 gap-4">
                <label className={`relative p-4 border rounded-lg cursor-pointer transition-colors ${
                  sessionType === 'video' ? 'border-primary-600 bg-primary-50' : 'border-gray-300 hover:border-gray-400'
                }`}>
                  <input
                    type="radio"
                    name="sessionType"
                    value="video"
                    checked={sessionType === 'video'}
                    onChange={(e) => setSessionType(e.target.value)}
                    className="sr-only"
                  />
                  <div className="flex items-center space-x-3">
                    <Video className={`w-5 h-5 ${sessionType === 'video' ? 'text-primary-600' : 'text-gray-400'}`} />
                    <div>
                      <p className="font-medium text-gray-900">Videochamada</p>
                      <p className="text-sm text-gray-600">Sessão online via video</p>
                    </div>
                  </div>
                </label>

                <label className={`relative p-4 border rounded-lg cursor-pointer transition-colors ${
                  sessionType === 'chat' ? 'border-primary-600 bg-primary-50' : 'border-gray-300 hover:border-gray-400'
                }`}>
                  <input
                    type="radio"
                    name="sessionType"
                    value="chat"
                    checked={sessionType === 'chat'}
                    onChange={(e) => setSessionType(e.target.value)}
                    className="sr-only"
                  />
                  <div className="flex items-center space-x-3">
                    <MessageSquare className={`w-5 h-5 ${sessionType === 'chat' ? 'text-primary-600' : 'text-gray-400'}`} />
                    <div>
                      <p className="font-medium text-gray-900">Chat</p>
                      <p className="text-sm text-gray-600">Conversa por mensagens</p>
                    </div>
                  </div>
                </label>
              </div>
            </div>

            {/* Date Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Escolha a Data
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {availableSlots.map((daySlot) => (
                  <button
                    key={daySlot.date}
                    type="button"
                    onClick={() => {
                      setSelectedDate(daySlot.date);
                      setSelectedTime(''); // Reset time when date changes
                    }}
                    className={`p-3 border rounded-lg text-left transition-colors ${
                      selectedDate === daySlot.date
                        ? 'border-primary-600 bg-primary-50'
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <Calendar className={`w-4 h-4 ${
                        selectedDate === daySlot.date ? 'text-primary-600' : 'text-gray-400'
                      }`} />
                      <div>
                        <p className="font-medium text-gray-900">{daySlot.day}</p>
                        <p className="text-sm text-gray-600">
                          {new Date(daySlot.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}
                        </p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Time Selection */}
            {selectedDate && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Escolha o Horário
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                  {availableSlots
                    .find(slot => slot.date === selectedDate)
                    ?.slots.map((time) => (
                      <button
                        key={time}
                        type="button"
                        onClick={() => setSelectedTime(time)}
                        className={`p-3 border rounded-lg text-center transition-colors ${
                          selectedTime === time
                            ? 'border-primary-600 bg-primary-50 text-primary-600'
                            : 'border-gray-300 hover:border-gray-400 text-gray-700'
                        }`}
                      >
                        <div className="flex items-center justify-center space-x-1">
                          <Clock className="w-4 h-4" />
                          <span className="font-medium">{time}</span>
                        </div>
                      </button>
                    ))}
                </div>
              </div>
            )}

            {/* Topic */}
            <div>
              <label htmlFor="topic" className="block text-sm font-medium text-gray-700 mb-2">
                Tópico da Sessão
              </label>
              <input
                type="text"
                id="topic"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                className="input-field"
                placeholder="Ex: Transição de carreira, Negociação salarial..."
                required
              />
            </div>

            {/* Description */}
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-2">
                Descrição (Opcional)
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                className="input-field"
                placeholder="Descreva brevemente o que você gostaria de discutir na sessão..."
              />
            </div>

            {/* Summary */}
            {selectedDate && selectedTime && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium text-gray-900 mb-2">Resumo da Sessão</h3>
                <div className="space-y-1 text-sm text-gray-600">
                  <p>📅 {new Date(selectedDate).toLocaleDateString('pt-BR', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}</p>
                  <p>⏰ {selectedTime}</p>
                  <p>💰 R$ {mentor.hourlyRate} (1 hora)</p>
                  <p>👥 {sessionType === 'video' ? 'Videochamada' : 'Chat'}</p>
                  {topic && <p>📝 {topic}</p>}
                </div>
              </div>
            )}

            {/* Submit Button */}
            <div className="flex space-x-4">
              <button
                type="button"
                className="btn-secondary flex-1"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={!selectedDate || !selectedTime || !topic}
                className="btn-primary flex-1 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Solicitar Agendamento
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};