import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Layout } from './components/Layout/Layout';
import { LoginForm } from './components/Auth/LoginForm';
import { RegisterForm } from './components/Auth/RegisterForm';
import { MentorDashboard } from './components/Dashboard/MentorDashboard';
import { MenteeDashboard } from './components/Dashboard/MenteeDashboard';
import { AdminDashboard } from './components/Dashboard/AdminDashboard';
import { MentorSearch } from './components/Mentors/MentorSearch';
import { ChatInterface } from './components/Chat/ChatInterface';
import { SessionBooking } from './components/Sessions/SessionBooking';
import { SessionRating } from './components/Sessions/SessionRating';

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

const Dashboard: React.FC = () => {
  const { user } = useAuth();

  if (!user) return null;

  switch (user.type) {
    case 'mentor':
      return <MentorDashboard />;
    case 'mentee':
      return <MenteeDashboard />;
    case 'admin':
      return <AdminDashboard />;
    default:
      return <MenteeDashboard />;
  }
};

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<LoginForm />} />
          <Route path="/register" element={<RegisterForm />} />
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <Layout>
                  <Dashboard />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/mentors"
            element={
              <ProtectedRoute>
                <Layout>
                  <MentorSearch />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/messages"
            element={
              <ProtectedRoute>
                <Layout>
                  <ChatInterface />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/book-session"
            element={
              <ProtectedRoute>
                <Layout>
                  <SessionBooking />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/session-rating"
            element={
              <ProtectedRoute>
                <Layout>
                  <SessionRating />
                </Layout>
              </ProtectedRoute>
            }
          />
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;