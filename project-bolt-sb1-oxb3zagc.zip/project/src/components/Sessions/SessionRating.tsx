import React, { useState } from 'react';
import { Star, Send, ThumbsUp, ThumbsDown } from 'lucide-react';

export const SessionRating: React.FC = () => {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [recommend, setRecommend] = useState<boolean | null>(null);

  const session = {
    id: '1',
    mentor: {
      name: 'Ana Silva',
      title: 'Senior Product Manager',
      company: 'Nubank',
      avatar: 'AS',
    },
    date: '15 de Janeiro, 2024',
    time: '14:00 - 15:00',
    topic: 'Desenvolvimento de Carreira',
    duration: 60,
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle rating submission
    console.log('Rating submitted:', {
      sessionId: session.id,
      rating,
      feedback,
      recommend,
    });
  };

  const ratingLabels = {
    1: 'Muito Ruim',
    2: 'Ruim',
    3: 'Regular',
    4: 'Bom',
    5: 'Excelente',
  };

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="card p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-success-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <ThumbsUp className="w-8 h-8 text-success-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Sessão Concluída!</h1>
          <p className="text-gray-600 mt-2">Como foi sua experiência com o mentor?</p>
        </div>

        {/* Session Summary */}
        <div className="bg-gray-50 p-4 rounded-lg mb-8">
          <div className="flex items-center space-x-4 mb-3">
            <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
              <span className="text-primary-600 font-semibold">{session.mentor.avatar}</span>
            </div>
            <div>
              <h3 className="font-medium text-gray-900">{session.mentor.name}</h3>
              <p className="text-sm text-gray-600">{session.mentor.title}</p>
              <p className="text-xs text-gray-500">{session.mentor.company}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
            <div>
              <span className="font-medium">Data:</span> {session.date}
            </div>
            <div>
              <span className="font-medium">Horário:</span> {session.time}
            </div>
            <div>
              <span className="font-medium">Tópico:</span> {session.topic}
            </div>
            <div>
              <span className="font-medium">Duração:</span> {session.duration} min
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Rating */}
          <div className="text-center">
            <label className="block text-lg font-medium text-gray-900 mb-4">
              Avalie sua sessão
            </label>
            <div className="flex items-center justify-center space-x-2 mb-4">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  className="p-1 transition-transform hover:scale-110"
                >
                  <Star
                    className={`w-8 h-8 ${
                      star <= (hoverRating || rating)
                        ? 'text-warning-500 fill-current'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
            </div>
            {(hoverRating || rating) > 0 && (
              <p className="text-sm text-gray-600">
                {ratingLabels[(hoverRating || rating) as keyof typeof ratingLabels]}
              </p>
            )}
          </div>

          {/* Recommend */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Você recomendaria este mentor?
            </label>
            <div className="flex space-x-4 justify-center">
              <button
                type="button"
                onClick={() => setRecommend(true)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg border transition-colors ${
                  recommend === true
                    ? 'border-success-600 bg-success-50 text-success-700'
                    : 'border-gray-300 text-gray-700 hover:border-gray-400'
                }`}
              >
                <ThumbsUp className="w-5 h-5" />
                <span>Sim</span>
              </button>
              <button
                type="button"
                onClick={() => setRecommend(false)}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg border transition-colors ${
                  recommend === false
                    ? 'border-red-600 bg-red-50 text-red-700'
                    : 'border-gray-300 text-gray-700 hover:border-gray-400'
                }`}
              >
                <ThumbsDown className="w-5 h-5" />
                <span>Não</span>
              </button>
            </div>
          </div>

          {/* Feedback */}
          <div>
            <label htmlFor="feedback" className="block text-sm font-medium text-gray-700 mb-2">
              Deixe um comentário (opcional)
            </label>
            <textarea
              id="feedback"
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              rows={4}
              className="input-field"
              placeholder="Como foi a sessão? O mentor foi útil? O que poderia ser melhorado?"
            />
          </div>

          {/* Submit */}
          <div className="flex space-x-4">
            <button
              type="button"
              className="btn-secondary flex-1"
            >
              Pular Avaliação
            </button>
            <button
              type="submit"
              disabled={rating === 0}
              className="btn-primary flex-1 flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
              <span>Enviar Avaliação</span>
            </button>
          </div>
        </form>

        {/* Next Steps */}
        <div className="mt-8 p-4 bg-primary-50 rounded-lg">
          <h3 className="font-medium text-primary-900 mb-2">Próximos Passos</h3>
          <div className="space-y-2 text-sm text-primary-700">
            <p>✓ Agende uma nova sessão com {session.mentor.name}</p>
            <p>✓ Explore outros mentores na sua área</p>
            <p>✓ Continue desenvolvendo suas habilidades</p>
          </div>
          <div className="flex space-x-3 mt-4">
            <button className="btn-primary text-sm">
              Agendar Nova Sessão
            </button>
            <button className="btn-secondary text-sm">
              Buscar Mentores
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};