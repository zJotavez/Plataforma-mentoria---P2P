import React, { useState } from 'react';
import { Search, Filter, Star, MapPin, Clock, User } from 'lucide-react';

export const MentorSearch: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedExpertise, setSelectedExpertise] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const expertiseAreas = [
    'Product Management',
    'Engineering Leadership',
    'UX/UI Design',
    'Data Science',
    'Marketing Digital',
    'Vendas',
    'Recursos Humanos',
    'Finanças',
    'Empreendedorismo',
    'Liderança',
  ];

  const mentors = [
    {
      id: '1',
      name: 'Ana Silva',
      title: 'Senior Product Manager',
      company: 'Nubank',
      location: 'São Paulo, SP',
      rating: 4.9,
      reviewCount: 127,
      hourlyRate: 150,
      experience: 8,
      expertise: ['Product Management', 'Growth', 'Strategy'],
      bio: 'Especialista em product management com 8+ anos de experiência em fintechs. Ajudo profissionais a fazer a transição para PM.',
      avatar: 'AS',
      isOnline: true,
      languages: ['Português', 'Inglês'],
      nextAvailable: 'Amanhã às 14:00',
    },
    {
      id: '2',
      name: 'Roberto Costa',
      title: 'Engineering Manager',
      company: 'iFood',
      location: 'São Paulo, SP',
      rating: 4.8,
      reviewCount: 89,
      hourlyRate: 180,
      experience: 12,
      expertise: ['Engineering Leadership', 'Team Building', 'Agile'],
      bio: 'Engineering Manager com 12 anos de experiência liderando times de alta performance em startups e scale-ups.',
      avatar: 'RC',
      isOnline: false,
      languages: ['Português', 'Inglês'],
      nextAvailable: 'Segunda às 09:00',
    },
    {
      id: '3',
      name: 'Mariana Fernandes',
      title: 'Head of Design',
      company: 'Mercado Livre',
      location: 'Rio de Janeiro, RJ',
      rating: 5.0,
      reviewCount: 203,
      hourlyRate: 200,
      experience: 10,
      expertise: ['UX Design', 'Design Leadership', 'Design System'],
      bio: 'Design leader apaixonada por criar experiências excepcionais. 10+ anos construindo produtos digitais.',
      avatar: 'MF',
      isOnline: true,
      languages: ['Português', 'Inglês', 'Espanhol'],
      nextAvailable: 'Hoje às 16:00',
    },
    {
      id: '4',
      name: 'Felipe Santos',
      title: 'Data Science Manager',
      company: 'Magazine Luiza',
      location: 'São Paulo, SP',
      rating: 4.7,
      reviewCount: 64,
      hourlyRate: 160,
      experience: 7,
      expertise: ['Data Science', 'Machine Learning', 'Analytics'],
      bio: 'Especialista em data science e machine learning, com foco em soluções de negócio data-driven.',
      avatar: 'FS',
      isOnline: false,
      languages: ['Português', 'Inglês'],
      nextAvailable: 'Terça às 10:30',
    },
  ];

  const filteredMentors = mentors.filter(mentor => {
    const matchesSearch = mentor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         mentor.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         mentor.expertise.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesExpertise = !selectedExpertise || 
                           mentor.expertise.some(skill => skill === selectedExpertise);
    
    return matchesSearch && matchesExpertise;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Encontrar Mentores</h1>
        <p className="text-gray-600 mt-2">Conecte-se com profissionais experientes na sua área</p>
      </div>

      {/* Search and Filters */}
      <div className="card p-6 mb-8">
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="flex-1 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-field pl-10"
              placeholder="Buscar por nome, cargo ou habilidade..."
            />
          </div>
          
          <select
            value={selectedExpertise}
            onChange={(e) => setSelectedExpertise(e.target.value)}
            className="input-field lg:w-64"
          >
            <option value="">Todas as áreas</option>
            {expertiseAreas.map(area => (
              <option key={area} value={area}>{area}</option>
            ))}
          </select>

          <button
            onClick={() => setShowFilters(!showFilters)}
            className="btn-secondary flex items-center space-x-2 lg:w-auto"
          >
            <Filter className="w-4 h-4" />
            <span>Filtros</span>
          </button>
        </div>

        {showFilters && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Experiência mínima
                </label>
                <select className="input-field">
                  <option value="">Qualquer</option>
                  <option value="3">3+ anos</option>
                  <option value="5">5+ anos</option>
                  <option value="10">10+ anos</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Localização
                </label>
                <select className="input-field">
                  <option value="">Qualquer</option>
                  <option value="sp">São Paulo</option>
                  <option value="rj">Rio de Janeiro</option>
                  <option value="remote">Remoto</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Valor por hora
                </label>
                <select className="input-field">
                  <option value="">Qualquer</option>
                  <option value="100">Até R$ 100</option>
                  <option value="150">Até R$ 150</option>
                  <option value="200">Até R$ 200</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Results */}
      <div className="mb-4 flex items-center justify-between">
        <p className="text-gray-600">
          {filteredMentors.length} mentor{filteredMentors.length !== 1 ? 'es' : ''} encontrado{filteredMentors.length !== 1 ? 's' : ''}
        </p>
        <select className="input-field w-auto">
          <option value="rating">Melhor avaliação</option>
          <option value="experience">Mais experiência</option>
          <option value="price-low">Menor preço</option>
          <option value="price-high">Maior preço</option>
        </select>
      </div>

      {/* Mentor Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredMentors.map((mentor) => (
          <div key={mentor.id} className="card p-6 hover:shadow-lg transition-shadow">
            <div className="flex items-start space-x-4">
              <div className="relative flex-shrink-0">
                <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center">
                  <span className="text-primary-600 font-semibold text-lg">{mentor.avatar}</span>
                </div>
                {mentor.isOnline && (
                  <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-success-500 border-2 border-white rounded-full"></div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-lg font-semibold text-gray-900 truncate">{mentor.name}</h3>
                  <div className="flex items-center ml-2">
                    <Star className="w-4 h-4 text-warning-500 fill-current" />
                    <span className="text-sm text-gray-600 ml-1">{mentor.rating}</span>
                    <span className="text-xs text-gray-500 ml-1">({mentor.reviewCount})</span>
                  </div>
                </div>

                <p className="text-primary-600 font-medium">{mentor.title}</p>
                <p className="text-gray-600 text-sm">{mentor.company}</p>

                <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 mr-1" />
                    {mentor.location}
                  </div>
                  <div className="flex items-center">
                    <User className="w-4 h-4 mr-1" />
                    {mentor.experience} anos
                  </div>
                </div>

                <p className="text-gray-700 text-sm mt-3 line-clamp-2">{mentor.bio}</p>

                <div className="flex flex-wrap gap-1 mt-3">
                  {mentor.expertise.slice(0, 3).map((skill) => (
                    <span key={skill} className="text-xs bg-primary-100 text-primary-700 px-2 py-1 rounded">
                      {skill}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between mt-4">
                  <div className="flex items-center space-x-4">
                    <span className="text-lg font-bold text-gray-900">
                      R$ {mentor.hourlyRate}/h
                    </span>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="w-4 h-4 mr-1" />
                      {mentor.nextAvailable}
                    </div>
                  </div>
                </div>

                <div className="flex space-x-3 mt-4">
                  <button className="btn-primary flex-1">
                    Ver Perfil
                  </button>
                  <button className="btn-secondary flex-1">
                    Agendar Sessão
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredMentors.length === 0 && (
        <div className="text-center py-12">
          <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum mentor encontrado</h3>
          <p className="text-gray-600 mb-4">Tente ajustar seus filtros de busca</p>
          <button 
            onClick={() => {
              setSearchTerm('');
              setSelectedExpertise('');
            }}
            className="btn-primary"
          >
            Limpar Filtros
          </button>
        </div>
      )}
    </div>
  );
};