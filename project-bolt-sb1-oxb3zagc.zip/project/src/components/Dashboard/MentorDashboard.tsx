import React from 'react';
import { Calendar, Star, Users, Clock, TrendingUp, MessageSquare } from 'lucide-react';

export const MentorDashboard: React.FC = () => {
  const stats = [
    { label: 'Sessões este mês', value: '12', icon: Calendar, color: 'text-primary-600' },
    { label: 'Avaliação média', value: '4.8', icon: Star, color: 'text-warning-600' },
    { label: 'Total de mentees', value: '28', icon: Users, color: 'text-success-600' },
    { label: 'Horas de mentoria', value: '156', icon: Clock, color: 'text-purple-600' },
  ];

  const upcomingSessions = [
    {
      id: '1',
      mentee: 'João Silva',
      title: 'Planejamento de Carreira',
      time: '14:00',
      date: 'Hoje',
      duration: '60 min',
    },
    {
      id: '2',
      mentee: 'Maria Santos',
      title: 'Transição de Carreira',
      time: '16:30',
      date: 'Amanhã',
      duration: '45 min',
    },
    {
      id: '3',
      mentee: 'Pedro Costa',
      title: 'Desenvolvimento de Liderança',
      time: '10:00',
      date: '15 Jan',
      duration: '60 min',
    },
  ];

  const recentReviews = [
    {
      id: '1',
      mentee: 'Ana Oliveira',
      rating: 5,
      comment: 'Excelente orientação sobre desenvolvimento de produto. Muito útil!',
      date: '2 dias atrás',
    },
    {
      id: '2',
      mentee: 'Carlos Lima',
      rating: 5,
      comment: 'Mentor muito experiente e atencioso. Recomendo!',
      date: '5 dias atrás',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard do Mentor</h1>
        <p className="text-gray-600 mt-2">Gerencie suas sessões e acompanhe seu desempenho</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => (
          <div key={stat.label} className="card p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <stat.icon className={`w-8 h-8 ${stat.color}`} />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-sm text-gray-600">{stat.label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Upcoming Sessions */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Próximas Sessões</h2>
            <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">
              Ver todas
            </button>
          </div>
          <div className="space-y-4">
            {upcomingSessions.map((session) => (
              <div key={session.id} className="flex items-center p-4 bg-gray-50 rounded-lg">
                <div className="flex-shrink-0 w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-primary-600" />
                </div>
                <div className="ml-4 flex-1">
                  <h3 className="text-sm font-medium text-gray-900">{session.title}</h3>
                  <p className="text-sm text-gray-600">com {session.mentee}</p>
                  <p className="text-xs text-gray-500">{session.date} às {session.time} • {session.duration}</p>
                </div>
                <button className="btn-primary text-sm px-4 py-2">
                  Iniciar
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Reviews */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Avaliações Recentes</h2>
            <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">
              Ver todas
            </button>
          </div>
          <div className="space-y-4">
            {recentReviews.map((review) => (
              <div key={review.id} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium text-gray-900">{review.mentee}</h3>
                  <div className="flex items-center">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-warning-500 fill-current" />
                    ))}
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-2">{review.comment}</p>
                <p className="text-xs text-gray-500">{review.date}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        <div className="card p-6 text-center">
          <TrendingUp className="w-12 h-12 text-primary-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Relatório de Performance</h3>
          <p className="text-gray-600 text-sm mb-4">Veja estatísticas detalhadas das suas mentorias</p>
          <button className="btn-primary w-full">Ver Relatório</button>
        </div>

        <div className="card p-6 text-center">
          <MessageSquare className="w-12 h-12 text-success-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Mensagens</h3>
          <p className="text-gray-600 text-sm mb-4">Responda às mensagens dos seus mentees</p>
          <button className="btn-secondary w-full">Abrir Chat</button>
        </div>

        <div className="card p-6 text-center">
          <Calendar className="w-12 h-12 text-warning-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Disponibilidade</h3>
          <p className="text-gray-600 text-sm mb-4">Gerencie seus horários disponíveis</p>
          <button className="btn-secondary w-full">Configurar</button>
        </div>
      </div>
    </div>
  );
};