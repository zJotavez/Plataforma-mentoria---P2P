import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Search, MessageCircle, Calendar, Settings } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const MobileNav: React.FC = () => {
  const { user } = useAuth();
  const location = useLocation();

  if (!user) return null;

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50">
      <div className="flex justify-around items-center h-16">
        <Link
          to="/dashboard"
          className={`flex flex-col items-center space-y-1 p-2 ${
            isActive('/dashboard') ? 'text-primary-600' : 'text-gray-400'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-xs">Início</span>
        </Link>

        {user.type === 'mentee' && (
          <Link
            to="/mentors"
            className={`flex flex-col items-center space-y-1 p-2 ${
              isActive('/mentors') ? 'text-primary-600' : 'text-gray-400'
            }`}
          >
            <Search className="w-5 h-5" />
            <span className="text-xs">Mentores</span>
          </Link>
        )}

        {user.type === 'mentor' && (
          <Link
            to="/sessions"
            className={`flex flex-col items-center space-y-1 p-2 ${
              isActive('/sessions') ? 'text-primary-600' : 'text-gray-400'
            }`}
          >
            <Calendar className="w-5 h-5" />
            <span className="text-xs">Sessões</span>
          </Link>
        )}

        <Link
          to="/messages"
          className={`flex flex-col items-center space-y-1 p-2 relative ${
            isActive('/messages') ? 'text-primary-600' : 'text-gray-400'
          }`}
        >
          <MessageCircle className="w-5 h-5" />
          <span className="text-xs">Mensagens</span>
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-success-500 rounded-full text-xs text-white flex items-center justify-center">
            2
          </span>
        </Link>

        <Link
          to="/profile"
          className={`flex flex-col items-center space-y-1 p-2 ${
            isActive('/profile') ? 'text-primary-600' : 'text-gray-400'
          }`}
        >
          <Settings className="w-5 h-5" />
          <span className="text-xs">Perfil</span>
        </Link>
      </div>
    </nav>
  );
};