import React from 'react';
import { Search, Calendar, Star, BookOpen, Target, MessageSquare, Clock, User } from 'lucide-react';

export const MenteeDashboard: React.FC = () => {
  const stats = [
    { label: 'Sessões agendadas', value: '3', icon: Calendar, color: 'text-primary-600' },
    { label: 'Horas de mentoria', value: '24', icon: Clock, color: 'text-success-600' },
    { label: 'Mentores conectados', value: '5', icon: User, color: 'text-warning-600' },
    { label: 'Objetivos alcançados', value: '8', icon: Target, color: 'text-purple-600' },
  ];

  const upcomingSessions = [
    {
      id: '1',
      mentor: 'Ana Silva',
      title: 'Desenvolvimento de Carreira',
      time: '14:00',
      date: 'Hoje',
      duration: '60 min',
      avatar: 'AS',
    },
    {
      id: '2',
      mentor: 'Roberto Costa',
      title: 'Liderança e Gestão',
      time: '10:00',
      date: 'Amanhã',
      duration: '45 min',
      avatar: 'RC',
    },
  ];

  const recommendedMentors = [
    {
      id: '1',
      name: 'Mariana Fernandes',
      title: 'Product Manager Senior',
      company: 'Tech Corp',
      rating: 4.9,
      expertise: ['Product Management', 'UX Strategy', 'Growth'],
      avatar: 'MF',
    },
    {
      id: '2',
      name: 'Felipe Santos',
      title: 'Engineering Manager',
      company: 'StartupXYZ',
      rating: 4.8,
      expertise: ['Engineering Leadership', 'Team Building', 'Agile'],
      avatar: 'FS',
    },
  ];

  const learningGoals = [
    { id: '1', title: 'Transição para Product Manager', progress: 75, status: 'Em progresso' },
    { id: '2', title: 'Desenvolver habilidades de liderança', progress: 45, status: 'Em progresso' },
    { id: '3', title: 'Negociação salarial', progress: 100, status: 'Concluído' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Seu Dashboard</h1>
        <p className="text-gray-600 mt-2">Acompanhe seu progresso e próximas sessões</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => (
          <div key={stat.label} className="card p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <stat.icon className={`w-8 h-8 ${stat.color}`} />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-sm text-gray-600">{stat.label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Upcoming Sessions */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Próximas Sessões</h2>
            <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">
              Ver todas
            </button>
          </div>
          <div className="space-y-4">
            {upcomingSessions.map((session) => (
              <div key={session.id} className="flex items-center p-4 bg-gray-50 rounded-lg">
                <div className="flex-shrink-0 w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                  <span className="text-primary-600 font-semibold text-sm">{session.avatar}</span>
                </div>
                <div className="ml-4 flex-1">
                  <h3 className="text-sm font-medium text-gray-900">{session.title}</h3>
                  <p className="text-sm text-gray-600">com {session.mentor}</p>
                  <p className="text-xs text-gray-500">{session.date} às {session.time} • {session.duration}</p>
                </div>
                <button className="btn-primary text-sm px-4 py-2">
                  Entrar
                </button>
              </div>
            ))}
          </div>
          
          {upcomingSessions.length === 0 && (
            <div className="text-center py-8">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Nenhuma sessão agendada</p>
              <button className="btn-primary mt-4">
                Agendar Sessão
              </button>
            </div>
          )}
        </div>

        {/* Learning Goals */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Objetivos de Aprendizado</h2>
            <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">
              Adicionar
            </button>
          </div>
          <div className="space-y-4">
            {learningGoals.map((goal) => (
              <div key={goal.id} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-medium text-gray-900">{goal.title}</h3>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    goal.status === 'Concluído' 
                      ? 'bg-success-100 text-success-700' 
                      : 'bg-warning-100 text-warning-700'
                  }`}>
                    {goal.status}
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-primary-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${goal.progress}%` }}
                  ></div>
                </div>
                <p className="text-xs text-gray-500 mt-1">{goal.progress}% concluído</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recommended Mentors */}
      <div className="card p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Mentores Recomendados</h2>
          <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">
            Ver todos
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {recommendedMentors.map((mentor) => (
            <div key={mentor.id} className="p-4 bg-gray-50 rounded-lg">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                  <span className="text-primary-600 font-semibold text-sm">{mentor.avatar}</span>
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-medium text-gray-900">{mentor.name}</h3>
                  <p className="text-sm text-gray-600">{mentor.title}</p>
                  <p className="text-xs text-gray-500">{mentor.company}</p>
                  <div className="flex items-center mt-2">
                    <Star className="w-4 h-4 text-warning-500 fill-current" />
                    <span className="text-sm text-gray-600 ml-1">{mentor.rating}</span>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {mentor.expertise.slice(0, 2).map((skill) => (
                      <span key={skill} className="text-xs bg-primary-100 text-primary-700 px-2 py-1 rounded">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex space-x-2 mt-4">
                <button className="btn-primary flex-1 text-sm">
                  Ver Perfil
                </button>
                <button className="btn-secondary flex-1 text-sm">
                  Conectar
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card p-6 text-center">
          <Search className="w-12 h-12 text-primary-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Encontrar Mentores</h3>
          <p className="text-gray-600 text-sm mb-4">Busque mentores na sua área de interesse</p>
          <button className="btn-primary w-full">Buscar</button>
        </div>

        <div className="card p-6 text-center">
          <MessageSquare className="w-12 h-12 text-success-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Mensagens</h3>
          <p className="text-gray-600 text-sm mb-4">Continue conversas com seus mentores</p>
          <button className="btn-secondary w-full">Abrir Chat</button>
        </div>

        <div className="card p-6 text-center">
          <BookOpen className="w-12 h-12 text-warning-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Recursos</h3>
          <p className="text-gray-600 text-sm mb-4">Acesse materiais e guias de aprendizado</p>
          <button className="btn-secondary w-full">Explorar</button>
        </div>
      </div>
    </div>
  );
};