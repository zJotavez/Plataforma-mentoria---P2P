import React from 'react';
import { Users, UserCheck, Clock, AlertTriangle, TrendingUp, MessageCircle } from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const stats = [
    { label: 'Total Usuários', value: '1,284', icon: Users, color: 'text-primary-600' },
    { label: 'Mentores Ativos', value: '156', icon: UserCheck, color: 'text-success-600' },
    { label: 'Sessões Este Mês', value: '432', icon: Clock, color: 'text-warning-600' },
    { label: 'Pendências', value: '12', icon: AlertTriangle, color: 'text-red-600' },
  ];

  const pendingApprovals = [
    {
      id: '1',
      name: 'Ricardo Almeida',
      title: 'Senior Software Engineer',
      company: 'TechCorp',
      appliedAt: '2 dias atrás',
      experience: 8,
    },
    {
      id: '2',
      name: 'Fernanda Lima',
      title: 'Product Manager',
      company: 'StartupXYZ',
      appliedAt: '1 dia atrás',
      experience: 6,
    },
    {
      id: '3',
      name: 'Carlos Oliveira',
      title: 'UX Designer Senior',
      company: 'Design Studio',
      appliedAt: '3 horas atrás',
      experience: 5,
    },
  ];

  const recentActivity = [
    { id: '1', action: 'Nova sessão agendada', user: 'João Silva', time: '5 min atrás' },
    { id: '2', action: 'Mentor aprovado', user: 'Maria Santos', time: '15 min atrás' },
    { id: '3', action: 'Avaliação 5⭐ recebida', user: 'Pedro Costa', time: '1 hora atrás' },
    { id: '4', action: 'Novo usuário cadastrado', user: 'Ana Oliveira', time: '2 horas atrás' },
  ];

  const platformMetrics = [
    { label: 'Taxa de Conclusão', value: '94%', trend: '+2.3%', positive: true },
    { label: 'Satisfação Média', value: '4.8/5', trend: '+0.2', positive: true },
    { label: 'Tempo Médio de Resposta', value: '12min', trend: '-3min', positive: true },
    { label: 'Taxa de Retenção', value: '87%', trend: '+5.1%', positive: true },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Painel Administrativo</h1>
        <p className="text-gray-600 mt-2">Gerencie a plataforma e monitore métricas</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => (
          <div key={stat.label} className="card p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <stat.icon className={`w-8 h-8 ${stat.color}`} />
              </div>
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-sm text-gray-600">{stat.label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Pending Approvals */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Aprovações Pendentes</h2>
            <span className="bg-warning-100 text-warning-700 text-xs px-2 py-1 rounded-full">
              {pendingApprovals.length} pendentes
            </span>
          </div>
          <div className="space-y-4">
            {pendingApprovals.map((mentor) => (
              <div key={mentor.id} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-medium text-gray-900">{mentor.name}</h3>
                    <p className="text-sm text-gray-600">{mentor.title}</p>
                    <p className="text-xs text-gray-500">{mentor.company} • {mentor.experience} anos exp.</p>
                    <p className="text-xs text-gray-500">{mentor.appliedAt}</p>
                  </div>
                  <div className="flex space-x-2">
                    <button className="btn-success text-sm px-3 py-1">
                      Aprovar
                    </button>
                    <button className="bg-red-600 hover:bg-red-700 text-white text-sm px-3 py-1 rounded">
                      Rejeitar
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="card p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Atividade Recente</h2>
            <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">
              Ver todas
            </button>
          </div>
          <div className="space-y-4">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-center p-3 hover:bg-gray-50 rounded-lg">
                <div className="flex-shrink-0 w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                  <div className="w-2 h-2 bg-primary-600 rounded-full"></div>
                </div>
                <div className="ml-3 flex-1">
                  <p className="text-sm text-gray-900">{activity.action}</p>
                  <p className="text-xs text-gray-500">{activity.user} • {activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Platform Metrics */}
      <div className="card p-6 mb-8">
        <h2 className="text-xl font-semibold text-gray-900 mb-6">Métricas da Plataforma</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {platformMetrics.map((metric) => (
            <div key={metric.label} className="text-center">
              <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
              <p className="text-sm text-gray-600">{metric.label}</p>
              <p className={`text-xs mt-1 ${
                metric.positive ? 'text-success-600' : 'text-red-600'
              }`}>
                {metric.trend}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card p-6 text-center">
          <Users className="w-12 h-12 text-primary-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Gerenciar Usuários</h3>
          <p className="text-gray-600 text-sm mb-4">Visualizar e gerenciar todos os usuários</p>
          <button className="btn-primary w-full">Acessar</button>
        </div>

        <div className="card p-6 text-center">
          <TrendingUp className="w-12 h-12 text-success-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Relatórios</h3>
          <p className="text-gray-600 text-sm mb-4">Visualizar relatórios detalhados</p>
          <button className="btn-secondary w-full">Ver Relatórios</button>
        </div>

        <div className="card p-6 text-center">
          <MessageCircle className="w-12 h-12 text-warning-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Suporte</h3>
          <p className="text-gray-600 text-sm mb-4">Atender solicitações de suporte</p>
          <button className="btn-secondary w-full">Abrir Suporte</button>
        </div>
      </div>
    </div>
  );
};