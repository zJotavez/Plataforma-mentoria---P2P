export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  type: 'mentor' | 'mentee' | 'admin';
  createdAt: Date;
  isActive: boolean;
}

export interface Mentor extends User {
  type: 'mentor';
  title: string;
  company: string;
  expertise: string[];
  experience: number;
  bio: string;
  rating: number;
  totalSessions: number;
  hourlyRate?: number;
  availability: Availability[];
  isApproved: boolean;
  languages: string[];
  location: string;
}

export interface Mentee extends User {
  type: 'mentee';
  currentRole?: string;
  company?: string;
  interests: string[];
  experience: number;
  goals: string;
}

export interface Session {
  id: string;
  mentorId: string;
  menteeId: string;
  title: string;
  description: string;
  scheduledAt: Date;
  duration: number; // in minutes
  status: 'pending' | 'approved' | 'rejected' | 'completed' | 'cancelled';
  meetingLink?: string;
  notes?: string;
  rating?: number;
  feedback?: string;
  createdAt: Date;
}

export interface Message {
  id: string;
  sessionId: string;
  senderId: string;
  content: string;
  createdAt: Date;
  isRead: boolean;
}

export interface Availability {
  dayOfWeek: number; // 0 = Sunday, 1 = Monday, etc.
  startTime: string; // "09:00"
  endTime: string; // "17:00"
}

export interface Notification {
  id: string;
  userId: string;
  type: 'session_request' | 'session_approved' | 'session_cancelled' | 'new_message' | 'rating_received';
  title: string;
  message: string;
  isRead: boolean;
  createdAt: Date;
  actionUrl?: string;
}

export interface Review {
  id: string;
  sessionId: string;
  mentorId: string;
  menteeId: string;
  rating: number;
  comment: string;
  createdAt: Date;
}